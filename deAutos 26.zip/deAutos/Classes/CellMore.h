//  UICellConfig.h

#import <UIKit/UIKit.h>
@interface CellMore: UITableViewCell
{
	UIImageView * theimage;
	UIActivityIndicatorView * thesleep;
}

-(void) start;
-(void) stop;

@end





