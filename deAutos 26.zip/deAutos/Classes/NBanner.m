//
//  NBanner.m
//  Detelefoongids
//
//  Created by Moises Swiczar on 5/18/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "NBanner.h"


@implementation NBanner

@synthesize UrlImage, UrlClick,Imagefileindevice;


@end
